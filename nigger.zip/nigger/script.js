
document.querySelectorAll('.nav-links a').forEach(a => {
  const href = a.getAttribute('href');
  if (href && location.pathname.endsWith(href)) a.classList.add('active');
});


const tabs = document.querySelectorAll('.tab');
const cards = document.querySelectorAll('.menu-card');
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const cat = tab.dataset.cat;
    cards.forEach(c => {
      c.style.display = (cat === 'all' || c.dataset.cat === cat) ? '' : 'none';
    });
  });
});


const form = document.querySelector('.form');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    alert("Thanks! We'll be in touch soon.");
    form.reset();
  });
}

const y = document.getElementById('year');
if (y) y.textContent = new Date().getFullYear();
